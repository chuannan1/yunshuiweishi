#include "debug.h"

unsigned char KeyNum=0;//��ȡ����ֵ
unsigned char WIFIflag=0;//WIFi״̬��־λ
float ADCvalue;//��ȡADC��ֵ
float Dischange;//����ת����־
float Total;//��ˮ����
float Time;//ʱ��
int liuliang=0;
float liuliang2=0;
uint32_t time_countter=0;//����
float TDS=0;
char buffer[1024];//���建����
char SwitchFlag=0;//�ƶ˿���״̬��־λ
char TDSSetFlag=0;//TDS��ֵ���ñ�־λ
uint16_t ZTDSthreshold=300;
//static int random_int(int left, int right)//ģ����ˮ��
//{
//    int number = rand() % (right - left - 1) + left;
//    return number;
//}
//int get_flow(int min, int max)
//{
//    return random_int(min, max);
//}


void ESP8266_GETWifi(void)//����
{
    while (uartWriteWiFiStr("AT+RST\r\n") == RESET);
    while (uartWriteWiFiStr("AT+CWJAP=LY,20040122\r\n") == RESET);//esp8266����WIFI
    Delay_Ms(200);
    while (uartWriteWiFiStr("AT+CIPSTATUS\r\n") == RESET);
    Delay_Ms(200);
    uartReadWiFi(buffer, 100);
    while(strstr(buffer,"+STATUS:5")==0);
    printf("\r\nRevceived %d bytes :\r\n%s", 11, buffer);
    WIFIflag=1;//WiFi��־λΪ1 ����ʾ����
    Paint_DrawImage(gImage_wifi,103,15,20,16);//����WIFI����ͼ��

    while (uartWriteWiFiStr((uint8_t *)"AT+IOTCFG=1026324504,565680,ESP8266MOD\r\n") == RESET);//esp8266����
    Delay_Ms(300);
    uartReadWiFi(buffer, 100);
    while(strstr(buffer,"+Event:Connect:0")==0)
    {
        while (uartWriteWiFiStr((uint8_t *)"AT+IOTCFG=1026324504,565680,ESP8266MOD\r\n") == RESET);//esp8266����
        uartReadWiFi(buffer, 100);
    }
    printf("\r\nRevceived %d bytes :\r\n%s", 20, buffer);
}
void ESP8266_SentData(void)//���ƶ˷������ݲ���ʾ
{
   if(SwitchFlag==1)
   {
       liuliang2=PWMI_GetFreq()/7.5;
//       liuliang=get_flow(50,70);
//       liuliang2=liuliang+600;//�����ճ���ˮ��
       Total=Total+(liuliang2/1700/60);
       Dischange=liuliang2;
       Serial_Printf("AT+IOTSEND=1,LEDOF,ON\r\n");
       Delay_Ms(200);
       uartReadWiFi(buffer, 100);
       while(strstr(buffer,"+Event:Send OK")==0)
       {
           Serial_Printf("AT+IOTSEND=1,LEDOF,ON\r\n");
           Delay_Ms(100);
       }
   }
   else if(SwitchFlag==0)
   {
       Dischange=0;
       Serial_Printf("AT+IOTSEND=1,LEDOF,OFF\r\n");
       Delay_Ms(200);
       uartReadWiFi(buffer, 100);
       while(strstr(buffer,"+Event:Send OK")==0)
       {
           Serial_Printf("AT+IOTSEND=1,LEDOF,OFF\r\n");
           Delay_Ms(100);
       }
   }
   Time=time_countter;//TIME
   Serial_Printf("AT+IOTSEND=0,Time,%d\r\n",(uint32_t)Time);
   Delay_Ms(200);
   uartReadWiFi(buffer, 100);
   while(strstr(buffer,"+Event:Send OK")==0)
   {
       Serial_Printf("AT+IOTSEND=0,Time,%d\r\n",(uint32_t)Time);
       Delay_Ms(100);
       printf("\r\nRevceived %d bytes :\r\n%s", 20, buffer);
   }
    //����
   Serial_Printf("AT+IOTSEND=0,Dischange(L/h),%d\r\n",(uint32_t)Dischange);
   Delay_Ms(200);
   uartReadWiFi(buffer, 50);
   while(strstr(buffer,"+Event:Send OK")==0)
   {
       Serial_Printf("AT+IOTSEND=0,Dischange(L/h),%d\r\n",(uint32_t)Dischange);
       Delay_Ms(100);
   }
   TDS=GETTDS(ADCvalue);//TDS
   Serial_Printf("AT+IOTSEND=0,TDS,%d\r\n",(uint32_t)TDS);
   Delay_Ms(200);
   uartReadWiFi(buffer, 100);
   while(strstr(buffer,"+Event:Send OK")==0)
   {
      Serial_Printf("AT+IOTSEND=0,TDS,%d\r\n",(uint32_t)TDS);
      Delay_Ms(100);
   }
    //������
   Serial_Printf("AT+IOTSEND=0,Total,%f\r\n",Total);
   Delay_Ms(200);
   uartReadWiFi(buffer, 50);
   while(strstr(buffer,"+Event:Send OK")==0)
   {
       Serial_Printf("AT+IOTSEND=0,Total,%f\r\n",Total);
       Delay_Ms(100);
   }

   LCD_ShowIntNum(45,110,(uint32_t)Dischange,3,GREEN,WHITE,24);//��λʱ�������
   LCD_ShowIntNum(65,140,time_countter,4,RED,WHITE,16);//gImage_time
   //LCD_ShowFloatNum1(45,50,GETTDS(ADCvalue),5,GREEN,WHITE,16);//��ʾTDSֵ
   LCD_ShowFloatNum1(45,83,Total,5,GREEN,WHITE,16);//������
}
void ESp8266_GetData(void)//���ƶ˶�ȡ���ݲ���Ӧ
{
    int num = uartAvailableWiFi();
    if (num > 0)
    {
        uartReadWiFi(buffer, num);
        buffer[num] = '\0';
        printf("\r\nRevceived %d bytes :\r\n%s", num, buffer);
    }
    if(NULL!=strstr(buffer,"1010"))
    {
       WORK_ON();FLOW_ON();SwitchFlag=1;

    }
    else if(NULL!=strstr(buffer,"2222"))
    {
       WORK_OFF();FLOW_OFF();SwitchFlag=0;
    }
}




int main(void)
{
    GPIO_INIT();//ʹ�������õ��Ķ˿�
    LCD_Init();//��Ļ��ʼ��
    LCD_Fill(0,0,LCD_W,LCD_H,WHITE);//���װ�
    GUI_Init();
	SystemCoreClockUpdate();
	Delay_Init();
	USART_Printf_Init(115200);
	ADC1_Init();//TDS����ֵ��ʼ��
	TIM6_Init(20000-1, 1440-1);//��ʱ6 200ms
	TIM7_Init(40000-1, 1440-1);//��ʱ7 400ms
	DMA_INIT();//DMAʹ��
	USARTx_init(); /* USART INIT */
	USART_DMACmd(UART6, USART_DMAReq_Tx | USART_DMAReq_Rx, ENABLE);//ʹ�ܴ���DMA
	PWMI_Init(65535,144);
	ESP8266_GETWifi();//����
	while(1)
    {
	   ESP8266_SentData();//���ƶ˷������ݲ���ʾ
    }
}



void TIM6_IRQHandler(void)   __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM6_IRQHandler(void)
{
    static unsigned int T0Count1=0,T0Count2=0,T0Count3;
    TIM_ClearFlag(TIM6, TIM_FLAG_Update);//�����־λ
    Key_Loop();
    if(SwitchFlag==1)//�����ܵ������źŲſ�ʼ��ʱ
    T0Count2++;
    else if(SwitchFlag==0)
    {
        T0Count2=0;time_countter=0;
    }
    if(T0Count2>=5)
    {
        time_countter++;
        T0Count2=0;
    }
    T0Count3++;
    if(T0Count3>=1)//��ȡESP8266��Ϣ
    {
        T0Count3=0;
        ESp8266_GetData();
    }
    if(WIFIflag==0)
    {
        T0Count1++;
        if(T0Count1>0 && T0Count1<=5)
        {
            WIFI_ON();
        }
        else if(T0Count1>5)
        {
            WIFI_OFF();
            if(T0Count1>=10)
            {
                T0Count1=0;
            }
        }
    }
    else if(WIFIflag==1)
    {
        WIFI_ON();
    }
    ADCvalue=(float)Get_ADC_Val(1)/ 4095 * 3.3;
}
void TIM7_IRQHandler(void)   __attribute__((interrupt("WCH-Interrupt-fast")));
void TIM7_IRQHandler(void)
{
    TIM_ClearFlag(TIM7, TIM_FLAG_Update);//�����־λ
    if(WIFIflag==1)
    {
        if(SwitchFlag!=0)
        {
            Paint_DrawImage(gImage_ON, 36, 6, 64, 32);
        }
        else {
            Paint_DrawImage(gImage_OFF, 36, 6, 64, 32);
        }
    }
    KeyNum=Key();//��ȡ����ֵ
    ZTDSthresholdvaule();
    BUZZER_alarm();
}


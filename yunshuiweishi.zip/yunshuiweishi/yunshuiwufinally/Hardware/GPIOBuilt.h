/*
 * GPIOBuilt.h
 *
 *  Created on: 2023��7��2��
 *      Author: lenovo
 */
#include "debug.h"
#ifndef HARDWARE_GPIOBUILT_H_
#define HARDWARE_GPIOBUILT_H_

#define BUZZER_ON()   GPIO_SetBits(GPIOA,GPIO_Pin_2);
#define BUZZER_OFF()  GPIO_ResetBits(GPIOA,GPIO_Pin_2);

#define WIFI_ON()   GPIO_SetBits(GPIOD,GPIO_Pin_6);
#define WIFI_OFF()  GPIO_ResetBits(GPIOD,GPIO_Pin_6);

#define WORK_ON()   GPIO_SetBits(GPIOB,GPIO_Pin_3);
#define WORK_OFF()  GPIO_ResetBits(GPIOB,GPIO_Pin_3);

#define FLOW_ON()   GPIO_SetBits(GPIOB,GPIO_Pin_9);
#define FLOW_OFF()  GPIO_ResetBits(GPIOB,GPIO_Pin_9);

#define MINUS()   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_9)

#define PLUS()   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_10)

#define OK()   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_11)

#define SET()   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_12)



#define LCD_BL_Pin GPIO_Pin_0
#define LCD_BL_GPIO_Port GPIOD

#define LCD_CS_Pin GPIO_Pin_1

#define LCD_DC_Pin GPIO_Pin_2

#define LCD_RES_Pin GPIO_Pin_3

#define LCD_DATA_Pin GPIO_Pin_4

#define LCD_CLK_Pin GPIO_Pin_5

void GPIO_INIT(void);

#endif /* HARDWARE_GPIOBUILT_H_ */

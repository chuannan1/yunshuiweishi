/*
 * TIM7interrupt.h
 *
 *  Created on: 2023��7��6��
 *      Author: lenovo
 */

#ifndef HARDWARE_TIM7INTERRUPT_H_
#define HARDWARE_TIM7INTERRUPT_H_

#include "debug.h"

void TIM7_Init( u16 arr, u16 psc);




#endif /* HARDWARE_TIM7INTERRUPT_H_ */

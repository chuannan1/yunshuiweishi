/*
 * image.h
 *
 *  Created on: 2023��7��3��
 *      Author: lenovo
 */

#ifndef HARDWARE_IMAGE_H_
#define HARDWARE_IMAGE_H_

extern const unsigned char gImage_tilte[];
extern const unsigned char gImage_wifi[];
extern const unsigned char gImage_DCF[];
extern const unsigned char gImage_tds[];
extern const unsigned char gImage_TW[];
extern const unsigned char gImage_flow[];
extern const unsigned char gImage_wendu[];
extern const unsigned char gImage_OFF[];
extern const unsigned char gImage_ON[];
extern const unsigned char gImage_time[];
extern const unsigned char gImage_THRE_ON[];
void GUI_Init(void);

#endif /* HARDWARE_IMAGE_H_ */

/*
 * TIM6Interrupt.h
 *
 *  Created on: 2023��7��2��
 *      Author: lenovo
 */

#ifndef HARDWARE_TIM6INTERRUPT_H_
#define HARDWARE_TIM6INTERRUPT_H_

#include "debug.h"

void TIM6_Init( u16 arr, u16 psc);



#endif /* HARDWARE_TIM6INTERRUPT_H_ */

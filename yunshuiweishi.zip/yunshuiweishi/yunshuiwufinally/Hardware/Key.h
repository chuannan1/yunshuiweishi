/*
 * Key.h
 *
 *  Created on: 2023��7��2��
 *      Author: lenovo
 */

#ifndef HARDWARE_KEY_H_
#define HARDWARE_KEY_H_

unsigned char Key(void);
void Key_Loop(void);

#endif /* HARDWARE_KEY_H_ */

/*
 * TDSSet.h
 *
 *  Created on: 2023��7��7��
 *      Author: lenovo
 */

#ifndef HARDWARE_TDSSET_H_
#define HARDWARE_TDSSET_H_
#define minus 1
#define plus 2
#define ok 3
#define set 4

void BUZZER_alarm(void);
void ZTDSthresholdvaule(void);

#endif /* HARDWARE_TDSSET_H_ */

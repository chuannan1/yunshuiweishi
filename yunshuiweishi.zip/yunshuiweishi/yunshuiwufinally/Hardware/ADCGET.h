/*
 * ADCGET.h
 *
 *  Created on: 2023��7��2��
 *      Author: lenovo
 */

#ifndef HARDWARE_ADCGET_H_
#define HARDWARE_ADCGET_H_

void ADC1_Init(void);
u16 Get_ADC_Val(u8 ch);
float GETTDS(float ADCvalue);//��ȡTDSֵ

#endif /* HARDWARE_ADCGET_H_ */

/*
 * TDSSet.c
 *
 *  Created on: 2023��7��7��
 *      Author: lenovo
 */
#include "debug.h"
#include "TDSSet.h"
#include "image.h"
#include "lcd.h"
#include "lcd_init.h"
#include "GPIOBuilt.h"
#include "ADCGET.h"

extern unsigned char KeyNum;
extern char TDSSetFlag;
extern uint16_t ZTDSthreshold;
extern float TDS;
extern float ADCvalue;//��ȡADC��ֵ
void ZTDSthresholdvaule(void)
{
    if(KeyNum==set)
    {
        TDSSetFlag=1;
    }
    if(TDSSetFlag==1)
    {
        if(KeyNum==plus)
        {
            ZTDSthreshold+=30;
        }
        else if(KeyNum==minus)
        {
            ZTDSthreshold-=30;
        }
        if(KeyNum==ok)
        {
            TDSSetFlag=0;
        }
        LCD_ShowIntNum(45,45,ZTDSthreshold,4,RED,WHITE,24);
        Paint_DrawImage(gImage_THRE_ON,0,42,32,32);
    }
    if(TDSSetFlag==0)
    {
    Paint_DrawImage(gImage_tds,2,40,32,32);
    LCD_ShowFloatNum1(45,50,GETTDS(ADCvalue),5,GREEN,WHITE,16);//��ʾTDSֵ
    }
}



void BUZZER_alarm(void)
{
    if(TDS>ZTDSthreshold && TDSSetFlag==0)
    {
        BUZZER_ON();
    }
    else if(TDS<=ZTDSthreshold || TDSSetFlag==1)
    {
        BUZZER_OFF();
    }
}





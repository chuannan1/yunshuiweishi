/*
 * PWI1.h
 *
 *  Created on: 2023��7��6��
 *      Author: lenovo
 */

#ifndef HARDWARE_PWI1_H_
#define HARDWARE_PWI1_H_

void PWMI_Init( u16 arr, u16 psc);
uint32_t PWMI_GetFreq(void);//��ȡƵ��

#endif /* HARDWARE_PWI1_H_ */
